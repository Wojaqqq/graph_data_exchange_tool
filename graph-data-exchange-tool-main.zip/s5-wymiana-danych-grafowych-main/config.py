neo4j_config = {
    "host": "bolt://localhost:7687",
    "user": "neo4j",
    "password": "neo4jpassword"
}

redisgraph_config = {
    "host": "172.18.0.3",
    "port": 6379
}

age_config = {
    "host": "172.18.0.6",
    "port": "5432",
    "dbname": "apache-age",
    "user": "postgres",
    "password": "postgres"
}
